# Upload API
File Upload API
Design By Nathan W

## Call API From Fiori
API Support:
* File Upload
* File Download
* Get File List With Directory
* Delete File
